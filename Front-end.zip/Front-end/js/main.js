import { initInput } from "./modules/input.js";
import { initVoice } from "./modules/voice.js";
import { initHalamanSimpan } from "./modules/halaman-simpan.js";
import { initHumberger } from "./humberger.js";

initHumberger();
initInput();
initVoice();
initHalamanSimpan();