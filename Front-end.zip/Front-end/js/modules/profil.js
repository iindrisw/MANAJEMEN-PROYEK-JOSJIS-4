const API_BASE_URL = "http://127.0.0.1:5000/api";

// Tampilan aktif disimpan di URL (?view=profile) supaya refresh tidak melempar user
// ke beranda. Tombol Beranda me-reload ke alamat polos, jadi penanda hilang sendiri.
const VIEW_PARAM = "view";

function setViewInUrl(view) {
  try {
    const url = new URL(window.location.href);
    if (view) {
      url.searchParams.set(VIEW_PARAM, view);
    } else {
      url.searchParams.delete(VIEW_PARAM);
    }
    history.replaceState(null, "", url);
  } catch (error) {
    // History API bisa ditolak (mis. file://). Tidak fatal.
    console.warn("Tidak dapat memperbarui URL tampilan:", error);
  }
}

export function initProfile() {
  const appShell = document.querySelector(".app-shell");
  const searchPanel = document.querySelector(".search-panel");
  const recipeContent = document.querySelector(".recipe-content");
  const sectionLabel = document.querySelector(".section-label");

  const profileView = document.querySelector("#view-profile");
  const savedView = document.querySelector("#view-saved");
  const guestModal = document.querySelector("#guest-modal");
  const closeGuestModalBtn = document.querySelector("#close-guest-modal");
  const btnModalLogin = document.querySelector("#btn-modal-login");

  const logoutModal = document.querySelector("#logout-confirm-modal");
  const btnTriggerLogout = document.querySelector("#btn-trigger-logout");
  const btnCancelLogout = document.querySelector("#btn-cancel-logout");
  const btnConfirmLogout = document.querySelector("#btn-confirm-logout");
  const btnGotoChangePass = document.querySelector("#btn-goto-changepass");

  const fullnameBox = document.querySelector("#profile-fullname");
  const emailBox = document.querySelector("#profile-email");

  const homeTitle = sectionLabel ? sectionLabel.textContent : "Cari Resep";

  function setProfileView(isOpen) {
    if (appShell) appShell.classList.toggle("is-profile-view", isOpen);
    if (profileView) profileView.hidden = !isOpen;
    if (searchPanel) searchPanel.hidden = isOpen;
    if (recipeContent) recipeContent.hidden = isOpen;

    if (savedView && isOpen) {
      savedView.hidden = true;
      if (appShell) appShell.classList.remove("is-saved-view");
    }

    if (sectionLabel) sectionLabel.textContent = isOpen ? "PROFIL" : homeTitle;
  }

  function showGuestModal() {
    if (guestModal instanceof HTMLDialogElement && !guestModal.open) {
      guestModal.showModal();
    }
  }

  function showProfileLoadError() {
    // Token TIDAK dihapus: ini bukan berarti user logout (server mati, offline, 5xx).
    if (fullnameBox) fullnameBox.textContent = "Gagal memuat profil";
    if (emailBox) emailBox.textContent = "Periksa koneksi lalu buka PROFIL lagi";
  }

  async function fetchUserData() {
    const token = localStorage.getItem("token");
    if (!token) {
      setProfileView(false);
      showGuestModal();
      return;
    }

    try {
      if (fullnameBox) fullnameBox.textContent = "Memuat...";
      if (emailBox) emailBox.textContent = "Memuat...";

      const response = await fetch(`${API_BASE_URL}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // Hanya 401 yang berarti token ditolak / kedaluwarsa -> baru anggap tamu.
      if (response.status === 401) {
        localStorage.removeItem("token");
        setViewInUrl(null);
        setProfileView(false);
        showGuestModal();
        return;
      }

      const result = await response.json().catch(() => null);
      if (!response.ok || !result || result.status === "error") {
        showProfileLoadError();
        return;
      }

      const user = result.data?.user || result.user || result.data || result;

      if (fullnameBox) {
        fullnameBox.textContent = user.nama || user.nama_lengkap || user.name || "Pengguna Racik Rasa";
      }
      if (emailBox) {
        emailBox.textContent = user.email || "-";
      }
    } catch (error) {
      // Jaringan putus / server tidak terjangkau: pertahankan sesi login.
      console.error("Gagal mengambil profil:", error);
      showProfileLoadError();
    }
  }

  // API Handler untuk Ubah Nama
  async function handleUbahNama(namaBaru) {
    const token = localStorage.getItem("token");
    if (!token) return;

    try {
      const response = await fetch(`${API_BASE_URL}/auth/profile`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({ nama: namaBaru }),
      });

      const result = await response.json();

      if (!response.ok || result.status === "error") {
        alert(result.message || "Gagal mengubah nama.");
        return;
      }

      const updatedUser = result.data?.user || result.data;
      if (fullnameBox) {
        fullnameBox.textContent = updatedUser?.nama || namaBaru;
      }
      alert("Nama berhasil diperbarui!");
    } catch (error) {
      console.error("Error ubah nama:", error);
      alert("Terjadi kesalahan koneksi ke server.");
    }
  }

  // Klik pada Kotak Nama Lengkap untuk Ubah Nama
  if (fullnameBox) {
    // Memberikan indikasi bahwa kotak nama bisa diklik
    fullnameBox.style.cursor = "pointer";
    fullnameBox.title = "Klik untuk mengubah nama";

    fullnameBox.parentElement?.addEventListener("click", () => {
      const namaLama = fullnameBox.textContent !== "Memuat..." ? fullnameBox.textContent : "";
      const namaBaru = prompt("Edit Nama Lengkap:", namaLama);
      
      if (namaBaru !== null && namaBaru.trim() !== "" && namaBaru.trim() !== namaLama) {
        void handleUbahNama(namaBaru.trim());
      }
    });
  }

  // Event Navigasi
  function handleProfileNavigation(e) {
    if (e) e.preventDefault();
    const token = localStorage.getItem("token");

    if (!token) {
      if (guestModal instanceof HTMLDialogElement && !guestModal.open) {
        guestModal.showModal();
      }
      return;
    }

    setProfileView(true);
    setViewInUrl("profile"); // menimpa ?view=saved jika sebelumnya di halaman simpan
    void fetchUserData();
  }

  const profileLinks = document.querySelectorAll('[data-nav-action="profile"]');
  profileLinks.forEach((link) => {
    link.addEventListener("click", handleProfileNavigation);
  });

  window.addEventListener("recipe:navigate-profile", () => {
    handleProfileNavigation();
  });

  window.addEventListener("recipe:navigate-home", () => {
    setViewInUrl(null);
    setProfileView(false);
    if (guestModal instanceof HTMLDialogElement && guestModal.open) guestModal.close();
    if (logoutModal instanceof HTMLDialogElement && logoutModal.open) logoutModal.close();
  });

  // Modal Handlers
  if (btnModalLogin) {
    btnModalLogin.addEventListener("click", () => {
      if (guestModal instanceof HTMLDialogElement) guestModal.close();
      window.location.assign("login.html");
    });
  }

  if (closeGuestModalBtn) {
    closeGuestModalBtn.addEventListener("click", () => {
      if (guestModal instanceof HTMLDialogElement) guestModal.close();
    });
  }

  if (btnGotoChangePass) {
    btnGotoChangePass.addEventListener("click", () => {
      window.location.assign("change-password.html");
    });
  }

  if (btnTriggerLogout) {
    btnTriggerLogout.addEventListener("click", () => {
      if (logoutModal instanceof HTMLDialogElement && !logoutModal.open) {
        logoutModal.showModal();
      }
    });
  }

  if (btnCancelLogout) {
    btnCancelLogout.addEventListener("click", () => {
      if (logoutModal instanceof HTMLDialogElement) {
        logoutModal.close();
      }
    });
  }

  if (btnConfirmLogout) {
    btnConfirmLogout.addEventListener("click", async () => {
      const token = localStorage.getItem("token");

      if (token) {
        try {
          await fetch(`${API_BASE_URL}/auth/logout`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${token}`,
            },
          });
        } catch (err) {
          console.warn("Gagal request logout ke BE:", err);
        }
      }

      localStorage.removeItem("token");
      if (logoutModal instanceof HTMLDialogElement) {
        logoutModal.close();
      }
      setProfileView(false);
      window.location.assign("login.html");
    });
  }

  // Pulihkan halaman profil setelah refresh (?view=profile). Layar detail (?recipe=ID)
  // diutamakan; tanpa token tidak ada profil untuk ditampilkan.
  const params = new URLSearchParams(window.location.search);
  if (params.get(VIEW_PARAM) === "profile") {
    if (params.has("recipe") || !localStorage.getItem("token")) {
      setViewInUrl(null);
    } else {
      setProfileView(true);
      window.dispatchEvent(new Event("recipe:profile-view-restored"));
      void fetchUserData();
    }
  }
}