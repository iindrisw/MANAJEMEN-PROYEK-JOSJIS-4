export function initHumberger() {
  const menuButton = document.querySelector("#menu-button");
  const navigation = document.querySelector("#bottom-nav");
  const drawerBackdrop = document.querySelector("#drawer-backdrop");
  const brandLink = document.querySelector("[data-home-link]");
  const bookmarkUnavailableDialog = document.querySelector(
    "#bookmark-unavailable-dialog",
  );

  if (
    !(menuButton instanceof HTMLButtonElement) ||
    !(navigation instanceof HTMLElement) ||
    !(drawerBackdrop instanceof HTMLButtonElement) ||
    !(brandLink instanceof HTMLAnchorElement) ||
    !(bookmarkUnavailableDialog instanceof HTMLDialogElement)
  ) {
    throw new Error("Elemen navigasi tidak ditemukan.");
  }

  function setNavigationOpen(isOpen) {
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.setAttribute(
      "aria-label",
      isOpen ? "Tutup navigasi" : "Buka navigasi",
    );
    navigation.setAttribute("aria-hidden", String(!isOpen));
    drawerBackdrop.setAttribute("aria-hidden", String(!isOpen));
    navigation.inert = !isOpen;
    drawerBackdrop.inert = !isOpen;

    if (isOpen) {
      navigation.hidden = false;
      drawerBackdrop.hidden = false;
      requestAnimationFrame(() => {
        if (menuButton.getAttribute("aria-expanded") === "true") {
          navigation.classList.add("is-open");
          drawerBackdrop.classList.add("is-open");
        }
      });
      return;
    }

    navigation.classList.remove("is-open");
    drawerBackdrop.classList.remove("is-open");
  }

  function setActiveNavigation(action) {
    for (const link of navigation.querySelectorAll("[data-nav-action]")) {
      const isActive = link.dataset.navAction === action;
      link.classList.toggle("is-active", isActive);
      if (isActive) {
        link.setAttribute("aria-current", "page");
      } else {
        link.removeAttribute("aria-current");
      }
    }
  }

  // Tautan "Daftar atau Masuk" hanya untuk tamu: sembunyikan jika sudah login.
  // (style.display dipakai karena CSS .drawer-signup menimpa atribut `hidden`)
  const signupLink = navigation.querySelector(".drawer-signup");
  function syncAuthLink() {
    if (signupLink instanceof HTMLElement) {
      signupLink.style.display = localStorage.getItem("token") ? "none" : "";
    }
  }
  syncAuthLink();

  menuButton.addEventListener("click", () => {
    const isExpanded = menuButton.getAttribute("aria-expanded") === "true";
    setNavigationOpen(!isExpanded);
  });

  drawerBackdrop.addEventListener("click", () => {
    setNavigationOpen(false);
    menuButton.focus();
  });

  // Beranda = reload bersih, tetapi lebih dulu kabari modul lain (halaman simpan,
  // profil, detail) lewat event; sebelumnya event ini tidak pernah terkirim dari
  // tombol Beranda sehingga penanda halaman simpan tidak ikut dibersihkan.
  function goHome() {
    window.dispatchEvent(new Event("recipe:navigate-home"));
    window.location.assign(window.location.pathname);
  }

  brandLink.addEventListener("click", (event) => {
    event.preventDefault();
    goHome();
  });

  navigation.addEventListener("click", (event) => {
    if (!(event.target instanceof Element)) {
      return;
    }

    const link = event.target.closest("[data-menu-link]");
    if (!(link instanceof HTMLAnchorElement)) {
      return;
    }

    event.preventDefault();
    setNavigationOpen(false);
    menuButton.focus();

    if (link.dataset.navAction === "home") {
      goHome();
    } else if (link.dataset.navAction === "bookmark") {
      setActiveNavigation("bookmark");
      window.dispatchEvent(new Event("recipe:navigate-saved"));
    } else if (link.dataset.navAction === "profile") {
      setActiveNavigation("profile");
      window.dispatchEvent(new Event("recipe:navigate-profile"));
    } else if (!link.dataset.navAction) {
      // Tautan biasa (mis. "Daftar atau Masuk") tetap harus berpindah halaman;
      // sebelumnya ikut di-preventDefault sehingga kliknya tidak berbuat apa-apa.
      window.location.assign(link.href);
    }
  });

  // Halaman simpan dipulihkan setelah refresh -> sorot menu SIMPAN di drawer.
  window.addEventListener("recipe:saved-view-restored", () => {
    setActiveNavigation("bookmark");
  });

  window.addEventListener("recipe:profile-view-restored", () => {
    setActiveNavigation("profile");
  });

  window.addEventListener("recipe:login-request", () => {
    setActiveNavigation("profile");
    window.dispatchEvent(new Event("recipe:auth-required"));
  });

  window.addEventListener("recipe:login-success", () => {
    setActiveNavigation("home");
    window.dispatchEvent(new Event("recipe:navigate-home"));
  });

  window.addEventListener("recipe:saved-auth-required", () => {
    const savedScreen = document.querySelector("#view-saved");
    if (!(savedScreen instanceof HTMLElement) || savedScreen.hidden) {
      setActiveNavigation("home");
    }

    window.dispatchEvent(new Event("recipe:auth-required"));
  });

  window.addEventListener("recipe:auth-required", () => {
    syncAuthLink();
    if (!bookmarkUnavailableDialog.open) {
      bookmarkUnavailableDialog.showModal();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (
      event.key === "Escape" &&
      menuButton.getAttribute("aria-expanded") === "true"
    ) {
      setNavigationOpen(false);
      menuButton.focus();
    }
  });
}